﻿string sourceFilePath = "D:\\TestFiles\\TestFile12000.txt";

string destFolder = "D:\\TestFiles\\GeneratedFiles";

try
{
    Directory.CreateDirectory(destFolder);

    int noOfCopies = 500000;

    string fileName = Path.GetFileNameWithoutExtension(sourceFilePath);
    string destFilePath = string.Empty;

    string searchText = "DUSDV12036";
    string replacementText = searchText.Substring(Math.Max(0, searchText.Length - 4));

    int fileNumberCount = Convert.ToInt32(replacementText);

    for (int i = 0; i < noOfCopies; i++)
    {
        fileNumberCount++;
        destFilePath = Path.Combine(destFolder, fileName + i + ".txt");

        File.Copy(sourceFilePath, destFilePath);

        string fileContent = File.ReadAllText(destFilePath);

        string updatedContent = fileContent.Replace(searchText, "DUSDV1" + fileNumberCount);

        File.WriteAllText(destFilePath, updatedContent);
    }
}
catch (Exception ex)
{
    throw;
}